# Anikoto 전체 목록 수집 — 2026-10-04

원본: https://anikoto.cz/filter?sort=name-az
전체 299페이지, 고유 작품 8,949개. 마지막 페이지 9개.

- anikoto-catalog.sqlite: 원본 작품 정보와 수집 페이지·재개 이력
- anikoto-catalog.jsonl: 이번 수집에서 관찰한 전체 작품
- anikoto-crawl-report.json: 완료 상태와 페이지·작품 수
- manifest.json: 파일별 SHA-256과 크기

작품 slug·사이트 ID·표시 제목·원제 원문·형식·장르·포스터 URL·회차 수·평점을 목록에서 읽었습니다. 없는 연도·방영 상태는 추정하지 않았습니다. 작품 연결은 모두 unmatched입니다. 상세 페이지와 영상·자막 파일은 받지 않았습니다. 기존 작품 DB와의 연결은 다음 단계에서 검토해야 합니다.

수집 도구: https://github.com/pingpingjinping/anime-db-download/pull/27
소스 커밋: b3850e92530e75e2d196fbcc356056148267f38f
SQLite integrity_check: ok. 페이지 번호 1–299, 페이지별 원본 ID·DB·JSONL의 고유 ID와 데이터가 모두 일치합니다.
